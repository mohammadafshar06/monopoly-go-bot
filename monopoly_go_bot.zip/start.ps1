#!/usr/bin/env pwsh

Start-Process -FilePath python.exe -Verb RunAs -ArgumentList main.py
